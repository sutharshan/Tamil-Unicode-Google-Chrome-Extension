﻿
<!-- Begin
var eelam;
function startText11() {
eelam = document.tamuni.box1.value;
eelam = eelam.replace(/;f/g, "ந்");
eelam = eelam.replace(/;/g, "ந");
eelam = eelam.replace(/நq/g, "நா");
eelam = eelam.replace(/நs/g, "நி");
eelam = eelam.replace(/நw/g, "நீ");
eelam = eelam.replace(/நd/g, "நு");
eelam = eelam.replace(/நe/g, "நூ");

eelam = eelam.replace(/நg/g, "நெ");
eelam = eelam.replace(/நt/g, "நே");

eelam = eelam.replace(/நc/g, "நொ");

eelam = eelam.replace(/நx/g, "நோ");
eelam = eelam.replace(/நz/g, "நெள");
eelam = eelam.replace(/நr/g, "நை");

eelam = eelam.replace(/Tf/g, "க்ஷ்");
eelam = eelam.replace(/T/g, "க்ஷ");
eelam = eelam.replace(/க்ஷq/g, "க்ஷா");
eelam = eelam.replace(/க்ஷs/g, "க்ஷி");
eelam = eelam.replace(/க்ஷw/g, "க்ஷீ");
eelam = eelam.replace(/க்ஷd/g, "க்ஷு");
eelam = eelam.replace(/க்ஷe/g, "க்ஷூ");

eelam = eelam.replace(/க்ஷg/g, "க்ஷெ");
eelam = eelam.replace(/க்ஷt/g, "க்ஷே");

eelam = eelam.replace(/க்ஷc/g, "க்ஷொ");

eelam = eelam.replace(/க்ஷx/g, "க்ஷோ");
eelam = eelam.replace(/க்ஷz/g, "க்ஷெள");
eelam = eelam.replace(/க்ஷr/g, "க்ஷை");

eelam = eelam.replace(/hf/g, "க்");
eelam = eelam.replace(/h/g, "க");
eelam = eelam.replace(/கq/g, "கா");
eelam = eelam.replace(/கs/g, "கி");
eelam = eelam.replace(/கw/g, "கீ");
eelam = eelam.replace(/கd/g, "கு");
eelam = eelam.replace(/கe/g, "கூ");

eelam = eelam.replace(/கg/g, "கெ");
eelam = eelam.replace(/கt/g, "கே");

eelam = eelam.replace(/கc/g, "கொ");

eelam = eelam.replace(/கx/g, "கோ");
eelam = eelam.replace(/கz/g, "கெள");
eelam = eelam.replace(/கr/g, "கை");

eelam = eelam.replace(/vf/g, "வ்");
eelam = eelam.replace(/v/g, "வ");
eelam = eelam.replace(/வq/g, "வா");
eelam = eelam.replace(/வs/g, "வி");
eelam = eelam.replace(/வw/g, "வீ");
eelam = eelam.replace(/வd/g, "வு");
eelam = eelam.replace(/வe/g, "வூ");

eelam = eelam.replace(/வg/g, "வெ");
eelam = eelam.replace(/வt/g, "வே");

eelam = eelam.replace(/வc/g, "வொ");

eelam = eelam.replace(/வx/g, "வோ");
eelam = eelam.replace(/வz/g, "வெள");
eelam = eelam.replace(/வr/g, "வை");

eelam = eelam.replace(/bf/g, "ங்");
eelam = eelam.replace(/b/g, "ங");
eelam = eelam.replace(/ஙq/g, "ஙா");
eelam = eelam.replace(/ஙs/g, "ஙி");
eelam = eelam.replace(/ஙw/g, "ஙீ");
eelam = eelam.replace(/ஙd/g, "ஙு");
eelam = eelam.replace(/ஙe/g, "ஙூ");

eelam = eelam.replace(/ஙg/g, "ஙெ");
eelam = eelam.replace(/ஙt/g, "ஙே");

eelam = eelam.replace(/ஙc/g, "ஙொ");

eelam = eelam.replace(/ஙx/g, "ஙோ");
eelam = eelam.replace(/ஙz/g, "ஙெள");
eelam = eelam.replace(/ஙr/g, "ஙை");

eelam = eelam.replace(/\[f/g, "ச்");
eelam = eelam.replace(/\[/g, "ச");
eelam = eelam.replace(/சq/g, "சா");
eelam = eelam.replace(/சs/g, "சி");
eelam = eelam.replace(/சw/g, "சீ");
eelam = eelam.replace(/சd/g, "சு");
eelam = eelam.replace(/சe/g, "சூ");

eelam = eelam.replace(/சg/g, "செ");
eelam = eelam.replace(/சt/g, "சே");

eelam = eelam.replace(/சc/g, "சொ");

eelam = eelam.replace(/சx/g, "சோ");
eelam = eelam.replace(/சz/g, "செள");
eelam = eelam.replace(/சr/g, "சை");

eelam = eelam.replace(/Ef/g, "ஜ்");
eelam = eelam.replace(/E/g, "ஜ");
eelam = eelam.replace(/ஜq/g, "ஜா");
eelam = eelam.replace(/ஜs/g, "ஜி");
eelam = eelam.replace(/ஜw/g, "ஜீ");
eelam = eelam.replace(/ஜd/g, "ஜு");
eelam = eelam.replace(/ஜe/g, "ஜூ");

eelam = eelam.replace(/ஜg/g, "ஜெ");
eelam = eelam.replace(/ஜt/g, "ஜே");

eelam = eelam.replace(/ஜc/g, "ஜொ");

eelam = eelam.replace(/ஜx/g, "ஜோ");
eelam = eelam.replace(/ஜz/g, "ஜெள");
eelam = eelam.replace(/ஜr/g, "ஜை");


eelam = eelam.replace(/\]f/g, "ஞ்");
eelam = eelam.replace(/\]/g, "ஞ");
eelam = eelam.replace(/ஞq/g, "ஞா");
eelam = eelam.replace(/ஞs/g, "ஞி");
eelam = eelam.replace(/ஞw/g, "ஞீ");
eelam = eelam.replace(/ஞd/g, "ஞு");
eelam = eelam.replace(/ஞe/g, "ஞூ");

eelam = eelam.replace(/ஞg/g, "ஞெ");
eelam = eelam.replace(/ஞt/g, "ஞே");

eelam = eelam.replace(/ஞc/g, "ஞொ");

eelam = eelam.replace(/ஞx/g, "ஞோ");
eelam = eelam.replace(/ஞz/g, "ஞெள");
eelam = eelam.replace(/ஞr/g, "ஞை");

eelam = eelam.replace(/of/g, "ட்");
eelam = eelam.replace(/o/g, "ட");
eelam = eelam.replace(/டq/g, "டா");
eelam = eelam.replace(/டs/g, "டி");
eelam = eelam.replace(/டw/g, "டீ");
eelam = eelam.replace(/டd/g, "டு");
eelam = eelam.replace(/டe/g, "டூ");

eelam = eelam.replace(/டg/g, "டெ");
eelam = eelam.replace(/டt/g, "டே");

eelam = eelam.replace(/டc/g, "டொ");

eelam = eelam.replace(/டx/g, "டோ");
eelam = eelam.replace(/டz/g, "டெள");
eelam = eelam.replace(/டr/g, "டை");

eelam = eelam.replace(/pf/g, "ண்");
eelam = eelam.replace(/p/g, "ண");
eelam = eelam.replace(/ணq/g, "ணா");
eelam = eelam.replace(/ணs/g, "ணி");
eelam = eelam.replace(/ணw/g, "ணீ");
eelam = eelam.replace(/ணd/g, "ணு");
eelam = eelam.replace(/ணe/g, "ணூ");

eelam = eelam.replace(/ணg/g, "ணெ");
eelam = eelam.replace(/ணt/g, "ணே");

eelam = eelam.replace(/ணc/g, "ணொ");

eelam = eelam.replace(/ணx/g, "ணோ");
eelam = eelam.replace(/ணz/g, "ணெள");
eelam = eelam.replace(/ணr/g, "ணை");

eelam = eelam.replace(/lf/g, "த்");
eelam = eelam.replace(/l/g, "த");
eelam = eelam.replace(/தq/g, "தா");
eelam = eelam.replace(/தs/g, "தி");
eelam = eelam.replace(/தw/g, "தீ");
eelam = eelam.replace(/தd/g, "து");
eelam = eelam.replace(/தe/g, "தூ");

eelam = eelam.replace(/தg/g, "தெ");
eelam = eelam.replace(/தt/g, "தே");

eelam = eelam.replace(/தc/g, "தொ");

eelam = eelam.replace(/தx/g, "தோ");
eelam = eelam.replace(/தz/g, "தெள");
eelam = eelam.replace(/தr/g, "தை");

eelam = eelam.replace(/if/g, "ன்");
eelam = eelam.replace(/i/g, "ன");
eelam = eelam.replace(/னq/g, "னா");
eelam = eelam.replace(/னs/g, "னி");
eelam = eelam.replace(/னw/g, "னீ");
eelam = eelam.replace(/னd/g, "னு");
eelam = eelam.replace(/னe/g, "னூ");

eelam = eelam.replace(/னg/g, "னெ");
eelam = eelam.replace(/னt/g, "னே");

eelam = eelam.replace(/னc/g, "னொ");

eelam = eelam.replace(/னx/g, "னோ");
eelam = eelam.replace(/னz/g, "னெள");
eelam = eelam.replace(/னr/g, "னை");


eelam = eelam.replace(/jf/g, "ப்");
eelam = eelam.replace(/j/g, "ப");
eelam = eelam.replace(/பq/g, "பா");
eelam = eelam.replace(/பs/g, "பி");
eelam = eelam.replace(/பw/g, "பீ");
eelam = eelam.replace(/பd/g, "பு");
eelam = eelam.replace(/பe/g, "பூ");

eelam = eelam.replace(/பg/g, "பெ");
eelam = eelam.replace(/பt/g, "பே");

eelam = eelam.replace(/பc/g, "பொ");

eelam = eelam.replace(/பx/g, "போ");
eelam = eelam.replace(/பz/g, "பெள");
eelam = eelam.replace(/பr/g, "பை");
eelam = eelam.replace(/kf/g, "ம்");
eelam = eelam.replace(/k/g, "ம");
eelam = eelam.replace(/மq/g, "மா");
eelam = eelam.replace(/மs/g, "மி");
eelam = eelam.replace(/மw/g, "மீ");
eelam = eelam.replace(/மd/g, "மு");
eelam = eelam.replace(/மe/g, "மூ");

eelam = eelam.replace(/மg/g, "மெ");
eelam = eelam.replace(/மt/g, "மே");

eelam = eelam.replace(/மc/g, "மொ");

eelam = eelam.replace(/மx/g, "மோ");
eelam = eelam.replace(/மz/g, "மெள");
eelam = eelam.replace(/மr/g, "மை");

eelam = eelam.replace(/'f/g, "ய்");
eelam = eelam.replace(/'/g, "ய");
eelam = eelam.replace(/யq/g, "யா");
eelam = eelam.replace(/யs/g, "யி");
eelam = eelam.replace(/யw/g, "யீ");
eelam = eelam.replace(/யd/g, "யு");
eelam = eelam.replace(/யe/g, "யூ");

eelam = eelam.replace(/யg/g, "யெ");
eelam = eelam.replace(/யt/g, "யே");

eelam = eelam.replace(/யc/g, "யொ");

eelam = eelam.replace(/யx/g, "யோ");
eelam = eelam.replace(/யz/g, "யெள");
eelam = eelam.replace(/யr/g, "யை");

eelam = eelam.replace(/mf/g, "ர்");
eelam = eelam.replace(/m/g, "ர");
eelam = eelam.replace(/ரq/g, "ரா");
eelam = eelam.replace(/ரs/g, "ரி");
eelam = eelam.replace(/ரw/g, "ரீ");
eelam = eelam.replace(/ரd/g, "ரு");
eelam = eelam.replace(/ரe/g, "ரூ");

eelam = eelam.replace(/ரg/g, "ரெ");
eelam = eelam.replace(/ரt/g, "ரே");

eelam = eelam.replace(/ரc/g, "ரொ");

eelam = eelam.replace(/ரx/g, "ரோ");
eelam = eelam.replace(/ரz/g, "ரெள");
eelam = eelam.replace(/ரr/g, "ரை");
eelam = eelam.replace(/nf/g, "ல்");
eelam = eelam.replace(/n/g, "ல");
eelam = eelam.replace(/லq/g, "லா");
eelam = eelam.replace(/லs/g, "லி");
eelam = eelam.replace(/லw/g, "லீ");
eelam = eelam.replace(/லd/g, "லு");
eelam = eelam.replace(/லe/g, "லூ");

eelam = eelam.replace(/லg/g, "லெ");
eelam = eelam.replace(/லt/g, "லே");

eelam = eelam.replace(/லc/g, "லொ");

eelam = eelam.replace(/லx/g, "லோ");
eelam = eelam.replace(/லz/g, "லெள");
eelam = eelam.replace(/லr/g, "லை");

eelam = eelam.replace(/yf/g, "ள்");
eelam = eelam.replace(/y/g, "ள");
eelam = eelam.replace(/ளq/g, "ளா");
eelam = eelam.replace(/ளs/g, "ளி");
eelam = eelam.replace(/ளw/g, "ளீ");
eelam = eelam.replace(/ளd/g, "ளு");
eelam = eelam.replace(/ளe/g, "ளூ");

eelam = eelam.replace(/ளg/g, "ளெ");
eelam = eelam.replace(/ளt/g, "ளே");

eelam = eelam.replace(/ளc/g, "ளொ");

eelam = eelam.replace(/ளx/g, "ளோ");
eelam = eelam.replace(/ளz/g, "ளெள");
eelam = eelam.replace(/ளr/g, "ளை");

eelam = eelam.replace(/kf/g, "வ்");
eelam = eelam.replace(/k/g, "வ");
eelam = eelam.replace(/வq/g, "வா");
eelam = eelam.replace(/வs/g, "வி");
eelam = eelam.replace(/வw/g, "வீ");
eelam = eelam.replace(/வd/g, "வு");
eelam = eelam.replace(/வe/g, "வூ");

eelam = eelam.replace(/vg/g, "வெ");
eelam = eelam.replace(/vt/g, "வே");

eelam = eelam.replace(/வc/g, "வொ");

eelam = eelam.replace(/வx/g, "வோ");
eelam = eelam.replace(/வz/g, "வெவ");
eelam = eelam.replace(/வr/g, "வை");

eelam = eelam.replace(/\/f/g, "ழ்");
eelam = eelam.replace(/\//g, "ழ");
eelam = eelam.replace(/ழq/g, "ழா");
eelam = eelam.replace(/ழs/g, "ழி");
eelam = eelam.replace(/ழw/g, "ழீ");
eelam = eelam.replace(/ழd/g, "ழு");
eelam = eelam.replace(/ழe/g, "ழூ");

eelam = eelam.replace(/ழg/g, "ழெ");
eelam = eelam.replace(/ழt/g, "ழே");

eelam = eelam.replace(/ழc/g, "ழொ");

eelam = eelam.replace(/ழx/g, "ழோ");
eelam = eelam.replace(/ழz/g, "ழெழ");
eelam = eelam.replace(/ழr/g, "ழை");

eelam = eelam.replace(/uf/g, "ற்");
eelam = eelam.replace(/u/g, "ற");
eelam = eelam.replace(/றq/g, "றா");
eelam = eelam.replace(/றs/g, "றி");
eelam = eelam.replace(/றw/g, "றீ");
eelam = eelam.replace(/றd/g, "று");
eelam = eelam.replace(/றe/g, "றூ");

eelam = eelam.replace(/றg/g, "றெ");
eelam = eelam.replace(/றt/g, "றே");

eelam = eelam.replace(/றc/g, "றொ");

eelam = eelam.replace(/றx/g, "றோ");
eelam = eelam.replace(/றz/g, "றெற");
eelam = eelam.replace(/றr/g, "றை");
eelam = eelam.replace(/Rf/g, "ஹ்");
eelam = eelam.replace(/R/g, "ஹ");
eelam = eelam.replace(/ஹq/g, "ஹா");
eelam = eelam.replace(/ஹs/g, "ஹி");
eelam = eelam.replace(/ஹw/g, "ஹீ");
eelam = eelam.replace(/ஹd/g, "ஹு");
eelam = eelam.replace(/ஹe/g, "ஹூ");

eelam = eelam.replace(/ஹg/g, "ஹெ");
eelam = eelam.replace(/ஹt/g, "ஹே");

eelam = eelam.replace(/ஹc/g, "ஹொ");
eelam = eelam.replace(/ஹx/g, "ஹோ");
eelam = eelam.replace(/ஹz/g, "ஹெஹ");
eelam = eelam.replace(/ஹr/g, "ஹை");
eelam = eelam.replace(/Wf/g, "ஷ்");
eelam = eelam.replace(/W/g, "ஷ");
eelam = eelam.replace(/ஷq/g, "ஷா");
eelam = eelam.replace(/ஷs/g, "ஷி");
eelam = eelam.replace(/ஷw/g, "ஷீ");
eelam = eelam.replace(/ஷd/g, "ஷு");
eelam = eelam.replace(/ஷe/g, "ஷூ");

eelam = eelam.replace(/ஷg/g, "ஷெ");
eelam = eelam.replace(/ஷt/g, "ஷே");

eelam = eelam.replace(/ஷc/g, "ஷொ");

eelam = eelam.replace(/ஷx/g, "ஷோ");
eelam = eelam.replace(/ஷz/g, "ஷெஷ");
eelam = eelam.replace(/ஷr/g, "ஷை");

eelam = eelam.replace(/Qf/g, "ஸ்");
eelam = eelam.replace(/Q/g, "ஸ");
eelam = eelam.replace(/ஸq/g, "ஸா");
eelam = eelam.replace(/ஸs/g, "ஸி");
eelam = eelam.replace(/ஸw/g, "ஸீ");
eelam = eelam.replace(/ஸd/g, "ஸு");
eelam = eelam.replace(/ஸe/g, "ஸூ");

eelam = eelam.replace(/ஸg/g, "ஸெ");
eelam = eelam.replace(/ஸt/g, "ஸே");

eelam = eelam.replace(/ஸc/g, "ஸொ");

eelam = eelam.replace(/ஸx/g, "ஸோ");
eelam = eelam.replace(/ஸz/g, "ஸெஸ");
eelam = eelam.replace(/ஸr/g, "ஸை");


eelam = eelam.replace(/a/g, "அ");
eelam = eelam.replace(/q/g, "ஆ");
eelam = eelam.replace(/w/g, "ஈ");
eelam = eelam.replace(/d/g, "உ");
eelam = eelam.replace(/e/g, "ஊ");
eelam = eelam.replace(/g/g, "எ");
eelam = eelam.replace(/t/g, "ஏ");
eelam = eelam.replace(/r/g, "ஐ");
eelam = eelam.replace(/c/g, "ஒ")
eelam = eelam.replace(/x/g, "ஓ");
eelam = eelam.replace(/z/g, "ஔ");

eelam = eelam.replace(/"/g, "@");
eelam = eelam.replace(/q/g, "ஆ");
eelam = eelam.replace(/w/g, "ஈ");
eelam = eelam.replace(/d/g, "உ");
eelam = eelam.replace(/e/g, "ஊ");
eelam = eelam.replace(/g/g, "எ");
eelam = eelam.replace(/t/g, "ஏ");
eelam = eelam.replace(/r/g, "ஐ");
eelam = eelam.replace(/c/g, "ஒ")
eelam = eelam.replace(/x/g, "ஓ");
eelam = eelam.replace(/z/g, "ஔ");

eelam = eelam.replace(/F/g, "ஃ");



eelam = eelam.replace(/ஷஷ/g, "ஷ்ஷ");



eelam = eelam.replace(/னன/g, "ன்ன");

eelam = eelam.replace(/ஜஜ/g, "ஜ்ஜ");



eelam = eelam.replace(/மம/g, "ம்ம");
eelam = eelam.replace(/கக/g, "க்க");
eelam = eelam.replace(/ஙங/g, "ங்ங");
eelam = eelam.replace(/சச/g, "ச்ச");
eelam = eelam.replace(/ஜஜ/g, "ஜ்ஜ");
eelam = eelam.replace(/ஞஞ/g, "ஞ்ஞ");
eelam = eelam.replace(/டட/g, "ட்ட");
eelam = eelam.replace(/ணண/g, "ண்ண");
eelam = eelam.replace(/தத/g, "த்த");
eelam = eelam.replace(/நந/g, "ந்ந");
eelam = eelam.replace(/னன/g, "ன்ன");
eelam = eelam.replace(/பப/g, "ப்ப");
eelam = eelam.replace(/யய/g, "ய்ய");
eelam = eelam.replace(/ரர/g, "ர்ர");
eelam = eelam.replace(/றற/g, "ற்ற");
eelam = eelam.replace(/லல/g, "ல்ல");
eelam = eelam.replace(/ளள/g, "ள்ள");
eelam = eelam.replace(/ழழ/g, "ழ்ழ");
eelam = eelam.replace(/வவ/g, "வ்வ");
eelam = eelam.replace(/ஷஷ/g, "ஷ்ஷ");
eelam = eelam.replace(/ஸஸ/g, "ஸ்ஸ");
eelam = eelam.replace(/ஹஹ/g, "ஹ்ஹ");

eelam = eelam.replace(/னற/g, "ன்ற");

eelam = eelam.replace(/ஙக/g, "ங்க");

eelam = eelam.replace(/நத/g, "ந்த")



eelam = eelam.replace(/s/g, "இ");

eelam = eelam.replace(/Y/g, "ஸ்ரீ");

document.tamuni.box2.value=eelam;
}
//  End -->