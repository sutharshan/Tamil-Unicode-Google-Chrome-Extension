﻿<!-- Begin 
var eelam; 
function startText8() { 

eelam = document.tamuni.box1.value 
eelam = eelam.replace(/&/g, "க்ஷ");
eelam = eelam.replace(/&h/g, "க்ஷா");
eelam = eelam.replace(/i&/g, "க்ஷை");
eelam = eelam.replace(/&p/g, "க்ஷி");
eelam = eelam.replace(/&P/g, "க்ஷீ");
eelam = eelam.replace(/&%/g, "க்ஷு");
eelam = eelam.replace(/&\^/g, "க்ஷூ");
eelam = eelam.replace(/b&/g, "க்ஷெ");
eelam = eelam.replace(/n&/g, "க்ஷே");
eelam = eelam.replace(/b&h/g, "க்ஷொ");
eelam = eelam.replace(/n&h/g, "க்ஷோ");
eelam = eelam.replace(/b&s/g, "க்ஷௌ");
eelam = eelam.replace(/&‚/g, "க்ஷ்");
eelam = eelam.replace(/$\%/g, "ஜு");
eelam = eelam.replace(/\%/g, "ு");
eelam = eelam.replace(/\^/g, "ூ");
eelam = eelam.replace(/\//g, "0000");
eelam = eelam.replace(/h;/g, "ர்");
eelam = eelam.replace(/#;/g, "ஷ்");
eelam = eelam.replace(/z;/g, "ண்");
eelam = eelam.replace(/J}/g, "தூ");
eelam = eelam.replace(/b\$/g, "ஜெ");
eelam = eelam.replace(/b$s/g, "ஜௌ");
eelam = eelam.replace(/n$h/g, "ஜோ");
eelam = eelam.replace(/b$h/g, "ஜொ");
eelam = eelam.replace(/$h/g, "ஜா");
eelam = eelam.replace(/$p/g, "ஜி");
eelam = eelam.replace(/$P/g, "ஜீ");

eelam = eelam.replace(/$\\^/g, "ஜூ");
eelam = eelam.replace(/n$/g, "ஜே");
eelam = eelam.replace(/i$/g, "ஜை");
eelam = eelam.replace(/$;/g, "ஜ்");
eelam = eelam.replace(/\$/g, "ஜ");///////////////////////////////////+

eelam = eelam.replace(/bfs/g, "கௌ");
eelam = eelam.replace(/nfh/g, "கோ");
eelam = eelam.replace(/bfh/g, "கொ");
eelam = eelam.replace(/fh/g, "கா");
eelam = eelam.replace(/fp/g, "கி");
eelam = eelam.replace(/fP/g, "கீ");
eelam = eelam.replace(/F/g, "கு");
eelam = eelam.replace(/T/g, "கூ");
eelam = eelam.replace(/bf/g, "கெ");
eelam = eelam.replace(/nf/g, "கே");
eelam = eelam.replace(/if/g, "கை");
eelam = eelam.replace(/f;/g, "க்");
eelam = eelam.replace(/f/g, "க");///////////////////////////////////+

eelam = eelam.replace(/b's/g, "ஙௌ");
eelam = eelam.replace(/n'h/g, "ஙோ");
eelam = eelam.replace(/b'h/g, "ஙொ");
eelam = eelam.replace(/'h/g, "ஙா");
eelam = eelam.replace(/'p/g, "ஙி");
eelam = eelam.replace(/'P/g, "ஙீ");
eelam = eelam.replace(/b'/g, "ஙெ");
eelam = eelam.replace(/n'/g, "ஙே");
eelam = eelam.replace(/i'/g, "ஙை");
eelam = eelam.replace(/';/g, "ங்");
eelam = eelam.replace(/'/g, "ங");///////////////////////////////////+
eelam = eelam.replace(/brs/g, "சௌ");
eelam = eelam.replace(/nrh/g, "சோ");
eelam = eelam.replace(/brh/g, "சொ");
eelam = eelam.replace(/rh/g, "சா");
eelam = eelam.replace(/rp/g, "சி");
eelam = eelam.replace(/rP/g, "சீ");
eelam = eelam.replace(/R/g, "சு");
eelam = eelam.replace(/r{/g, "சூ");
eelam = eelam.replace(/br/g, "செ");
eelam = eelam.replace(/nr/g, "சே");
eelam = eelam.replace(/ir/g, "சை");
eelam = eelam.replace(/r;/g, "ச்");
eelam = eelam.replace(/r@/g, "ச்");
eelam = eelam.replace(/r/g, "ச");///////////////////////////////////+


eelam = eelam.replace(/b"s/g, "ஞௌ");
eelam = eelam.replace(/n"h/g, "ஞோ");
eelam = eelam.replace(/b"h/g, "ஞொ");
eelam = eelam.replace(/"h/g, "ஞா");
eelam = eelam.replace(/"p/g, "ஞி");
eelam = eelam.replace(/"P/g, "ஞீ");
eelam = eelam.replace(/b"/g, "ஞெ");
eelam = eelam.replace(/n"/g, "ஞே");
eelam = eelam.replace(/i"/g, "ஞை");
eelam = eelam.replace(/";/g, "ஞ்");
eelam = eelam.replace(/"/g, "ஞ");///////////////////////////////////+

eelam = eelam.replace(/bls/g, "டௌ");
eelam = eelam.replace(/nlh/g, "டோ");
eelam = eelam.replace(/blh/g, "டொ");
eelam = eelam.replace(/lh/g, "டா");
eelam = eelam.replace(/o/g, "டி");
eelam = eelam.replace(/O/g, "டீ");
eelam = eelam.replace(/L/g, "டு");
eelam = eelam.replace(/\?/g, "டூ");
eelam = eelam.replace(/bl/g, "டெ");
eelam = eelam.replace(/nl/g, "டே");
eelam = eelam.replace(/il/g, "டை");
eelam = eelam.replace(/l;/g, "ட்");
eelam = eelam.replace(/l/g, "ட");///////////////////////////////////+

eelam = eelam.replace(/bzs/g, "ணௌ");
eelam = eelam.replace(/nzh/g, "ணோ");
eelam = eelam.replace(/bzh/g, "ணொ");
eelam = eelam.replace(/zh/g, "ணா");
eelam = eelam.replace(/zp/g, "ணி");
eelam = eelam.replace(/zP/g, "ணீ");
eelam = eelam.replace(/q/g, "ணு");
eelam = eelam.replace(/q}/g, "ணூ");
eelam = eelam.replace(/bz/g, "ணெ");
eelam = eelam.replace(/nz/g, "ணே");
eelam = eelam.replace(/iz/g, "ணை");

eelam = eelam.replace(/z/g, "ண");///////////////////////////////////+
eelam = eelam.replace(/bjs/g, "தௌ");
eelam = eelam.replace(/njh/g, "தோ");
eelam = eelam.replace(/bjh/g, "தொ");
eelam = eelam.replace(/jh/g, "தா");
eelam = eelam.replace(/jp/g, "தி");
eelam = eelam.replace(/jP/g, "தீ");
eelam = eelam.replace(/J/g, "து");
eelam = eelam.replace(/bj/g, "தெ");
eelam = eelam.replace(/nj/g, "தே");
eelam = eelam.replace(/ij/g, "தை");
eelam = eelam.replace(/j;/g, "த்");
eelam = eelam.replace(/j/g, "த");///////////////////////////////////+

eelam = eelam.replace(/bes/g, "நௌ");
eelam = eelam.replace(/neh/g, "நோ");
eelam = eelam.replace(/beh/g, "நொ");
eelam = eelam.replace(/eh/g, "நா");
eelam = eelam.replace(/ep/g, "நி");
eelam = eelam.replace(/eP/g, "நீ");
eelam = eelam.replace(/E/g, "நு");
eelam = eelam.replace(/E}/g, "நூ");
eelam = eelam.replace(/be/g, "நெ");
eelam = eelam.replace(/ne/g, "நே");
eelam = eelam.replace(/ie/g, "நை");
eelam = eelam.replace(/e;/g, "ந்");
eelam = eelam.replace(/e/g, "ந");///////////////////////////////////+
eelam = eelam.replace(/bds/g, "னௌ");
eelam = eelam.replace(/ndh/g, "னோ");
eelam = eelam.replace(/bdh/g, "னொ");
eelam = eelam.replace(/dh/g, "னா");
eelam = eelam.replace(/dp/g, "னி");
eelam = eelam.replace(/dP/g, "னீ");
eelam = eelam.replace(/D/g, "னு");
eelam = eelam.replace(/D}/g, "னூ");
eelam = eelam.replace(/bd/g, "னெ");
eelam = eelam.replace(/nd/g, "னே");
eelam = eelam.replace(/id/g, "னை");
eelam = eelam.replace(/d;/g, "ன்");
eelam = eelam.replace(/d/g, "ன");///////////////////////////////////+


eelam = eelam.replace(/bgs/g, "பௌ");
eelam = eelam.replace(/ngh/g, "போ");
eelam = eelam.replace(/bgh/g, "பொ");
eelam = eelam.replace(/gh/g, "பா");
eelam = eelam.replace(/gp/g, "பி");
eelam = eelam.replace(/gP/g, "பீ");
eelam = eelam.replace(/g\[/g, "பு");
eelam = eelam.replace(/g{/g, "பூ");
eelam = eelam.replace(/bg/g, "பெ");
eelam = eelam.replace(/ng/g, "பே");
eelam = eelam.replace(/ig/g, "பை");
eelam = eelam.replace(/g;/g, "ப்");
eelam = eelam.replace(/g/g, "ப");///////////////////////////////////+
eelam = eelam.replace(/bks/g, "மௌ");
eelam = eelam.replace(/nkh/g, "மோ");
eelam = eelam.replace(/bkh/g, "மொ");
eelam = eelam.replace(/kh/g, "மா");
eelam = eelam.replace(/kp/g, "மி");
eelam = eelam.replace(/kP/g, "மீ");
eelam = eelam.replace(/K/g, "மு");
eelam = eelam.replace(/\\/g, "மூ");
eelam = eelam.replace(/bk/g, "மெ");
eelam = eelam.replace(/nk/g, "மே");
eelam = eelam.replace(/ik/g, "மை");
eelam = eelam.replace(/k;/g, "ம்");
eelam = eelam.replace(/k/g, "ம");///////////////////////////////////+

eelam = eelam.replace(/bas/g, "யௌ");
eelam = eelam.replace(/nah/g, "யோ");
eelam = eelam.replace(/bah/g, "யொ");
eelam = eelam.replace(/ah/g, "யா");
eelam = eelam.replace(/ap/g, "யி");
eelam = eelam.replace(/aP/g, "யீ");
eelam = eelam.replace(/a\[/g, "யு");
eelam = eelam.replace(/a{/g, "யூ");
eelam = eelam.replace(/ba/g, "யெ");
eelam = eelam.replace(/na/g, "யே");
eelam = eelam.replace(/ia/g, "யை");
eelam = eelam.replace(/a;/g, "ய்");
eelam = eelam.replace(/a/g, "ய");///////////////////////////////////+
eelam = eelam.replace(/bus/g, "ரௌ");
eelam = eelam.replace(/nuh/g, "ரோ");
eelam = eelam.replace(/buh/g, "ரொ");
eelam = eelam.replace(/uh/g, "ரா");
eelam = eelam.replace(/up/g, "ரி");
eelam = eelam.replace(/uP/g, "ரீ");
eelam = eelam.replace(/U/g, "ரு");
eelam = eelam.replace(/\+/g, "ரூ");
eelam = eelam.replace(/bu/g, "ரெ");
eelam = eelam.replace(/nu/g, "ரே");
eelam = eelam.replace(/iu/g, "ரை");
eelam = eelam.replace(/u;/g, "ர்");

eelam = eelam.replace(/u/g, "ர");///////////////////////////////////+


eelam = eelam.replace(/bys/g, "லௌ");
eelam = eelam.replace(/nyh/g, "லோ");
eelam = eelam.replace(/byh/g, "லொ");
eelam = eelam.replace(/yh/g, "லா");
eelam = eelam.replace(/yp/g, "லி");
eelam = eelam.replace(/yP/g, "லீ");
eelam = eelam.replace(/Y/g, "லு");
eelam = eelam.replace(/Y}/g, "லூ");
eelam = eelam.replace(/by/g, "லெ");
eelam = eelam.replace(/ny/g, "லே");
eelam = eelam.replace(/iy/g, "லை");
eelam = eelam.replace(/y;/g, "ல்");
eelam = eelam.replace(/y/g, "ல");///////////////////////////////////+

eelam = eelam.replace(/bss/g, "ளௌ");
eelam = eelam.replace(/nsh/g, "ளோ");
eelam = eelam.replace(/bsh/g, "ளொ");
eelam = eelam.replace(/sh/g, "ளா");
eelam = eelam.replace(/sp/g, "ளி");
eelam = eelam.replace(/sP/g, "ளீ");
eelam = eelam.replace(/S/g, "ளு");
eelam = eelam.replace(/\~/g, "ளூ");
eelam = eelam.replace(/bs/g, "ளெ");
eelam = eelam.replace(/ns/g, "ளே");
eelam = eelam.replace(/is/g, "ளை");
eelam = eelam.replace(/s;/g, "ள்");
eelam = eelam.replace(/s/g, "ள");///////////////////////////////////+

eelam = eelam.replace(/btt/g, "வௌ");
eelam = eelam.replace(/nth/g, "வோ");
eelam = eelam.replace(/bth/g, "வொ");
eelam = eelam.replace(/th/g, "வா");
eelam = eelam.replace(/tp/g, "வி");
eelam = eelam.replace(/tP/g, "வீ");
eelam = eelam.replace(/t\[/g, "வு");
eelam = eelam.replace(/t{/g, "வூ");
eelam = eelam.replace(/bt/g, "வெ");
eelam = eelam.replace(/nt/g, "வே");
eelam = eelam.replace(/it/g, "வை");
eelam = eelam.replace(/t;/g, "வ்");
eelam = eelam.replace(/t/g, "வ");///////////////////////////////////+


eelam = eelam.replace(/bww/g, "றௌ");
eelam = eelam.replace(/nww/g, "றோ");
eelam = eelam.replace(/bww/g, "றொ");
eelam = eelam.replace(/ww/g, "றா");
eelam = eelam.replace(/wp/g, "றி");
eelam = eelam.replace(/wP/g, "றீ");
eelam = eelam.replace(/W/g, "று");
eelam = eelam.replace(/W}/g, "றூ");
eelam = eelam.replace(/bw/g, "றெ");
eelam = eelam.replace(/nw/g, "றே");
eelam = eelam.replace(/iw/g, "றை");
eelam = eelam.replace(/w;/g, "ற்");
eelam = eelam.replace(/w/g, "ற");///////////////////////////////////+





eelam = eelam.replace(/bQQ/g, "ஹௌ");
eelam = eelam.replace(/nQQ/g, "ஹோ");
eelam = eelam.replace(/bQQ/g, "ஹொ");
eelam = eelam.replace(/QQ/g, "ஹா");
eelam = eelam.replace(/Qp/g, "ஹி");
eelam = eelam.replace(/QP/g, "ஹீ");
eelam = eelam.replace(/Q%/g, "ஹு");
eelam = eelam.replace(/Q\^/g, "ஹூ");
eelam = eelam.replace(/bQ/g, "ஹெ");
eelam = eelam.replace(/nQ/g, "ஹே");
eelam = eelam.replace(/iQ/g, "ஹை");
eelam = eelam.replace(/Q;/g, "ஹ்");
eelam = eelam.replace(/Q/g, "ஹ");///////////////////////////////////+


eelam = eelam.replace(/t/g, "வ");///////////////////////////////////+

eelam = eelam.replace(/bHH/g, "ழௌ");
eelam = eelam.replace(/nHh/g, "ழோ");
eelam = eelam.replace(/bHh/g, "ழொ");
eelam = eelam.replace(/Hh/g, "ழா");
eelam = eelam.replace(/Hp/g, "ழி");
eelam = eelam.replace(/HP/g, "ழீ");
eelam = eelam.replace(/G/g, "ழு");
eelam = eelam.replace(/\=/g, "ழூ");
eelam = eelam.replace(/bH/g, "ழெ");
eelam = eelam.replace(/nH/g, "ழே");
eelam = eelam.replace(/iH/g, "ழை");
eelam = eelam.replace(/H;/g, "ழ்");
eelam = eelam.replace(/H/g, "ழ");///////////////////////////////////+

eelam = eelam.replace(/öåå/g, "ஷௌ");
eelam = eelam.replace(/÷åõ/g, "ஷோ");
eelam = eelam.replace(/öåõ/g, "ஷொ");
eelam = eelam.replace(/åõ/g, "ஷா");
eelam = eelam.replace(/æ/g, "ஷி");
eelam = eelam.replace(/ç/g, "ஷீ");
eelam = eelam.replace(/åú/g, "ஷு");
eelam = eelam.replace(/åü/g, "ஷூ");
eelam = eelam.replace(/öå/g, "ஷெ");
eelam = eelam.replace(/÷å/g, "ஷே");
eelam = eelam.replace(/øå/g, "ஷை");
eelam = eelam.replace(/è/g, "ஷ்");
eelam = eelam.replace(/å/g, "ஷ");///////////////////////////////////

eelam = eelam.replace(/b##/g, "ஷௌ");
eelam = eelam.replace(/n##/g, "ஷோ");
eelam = eelam.replace(/b##/g, "ஷொ");
eelam = eelam.replace(/##/g, "ஷா");
eelam = eelam.replace(/#p/g, "ஷி");
eelam = eelam.replace(/#P/g, "ஷீ");
eelam = eelam.replace(/#%/g, "ஷு");
eelam = eelam.replace(/#^/g, "ஷூ");
eelam = eelam.replace(/b#/g, "ஷெ");
eelam = eelam.replace(/n#/g, "ஷே");
eelam = eelam.replace(/i#/g, "ஷை");

eelam = eelam.replace(/#/g, "ஷ");///////////////////////////////////+

eelam = eelam.replace(/b!!/g, "ஸௌ");
eelam = eelam.replace(/n!!/g, "ஸோ");
eelam = eelam.replace(/b!!/g, "ஸொ");
eelam = eelam.replace(/!!/g, "ஸா");
eelam = eelam.replace(/!p/g, "ஸி");
eelam = eelam.replace(/!P/g, "ஸீ");
eelam = eelam.replace(/!%/g, "ஸு");
eelam = eelam.replace(/!^/g, "ஸூ");
eelam = eelam.replace(/b!/g, "ஸெ");
eelam = eelam.replace(/n!/g, "ஸே");
eelam = eelam.replace(/i!/g, "ஸை");
eelam = eelam.replace(/!;/g, "ஸ்");
eelam = eelam.replace(/!/g, "ஸ");///////////////////////////////////


eelam = eelam.replace(/m/g, "அ");
eelam = eelam.replace(/M/g, "ஆ");

eelam = eelam.replace(/</g, "ஈ");
eelam = eelam.replace(/c/g, "உ");
eelam = eelam.replace(/C/g, "ஊ");
eelam = eelam.replace(/v/g, "எ");
eelam = eelam.replace(/V/g, "ஏ");
eelam = eelam.replace(/I/g, "ஐ");
eelam = eelam.replace(/x/g, "ஒ")
eelam = eelam.replace(/X/g, "ஓ");
eelam = eelam.replace(/cs/g, "ஔ");


eelam = eelam.replace(/`/g, "ஃ");
eelam = eelam.replace(/,/g, "இ");
eelam = eelam.replace(/\|/g, "ஸ்ரீ");
eelam = eelam.replace(/ˆ/g, "=");
eelam = eelam.replace(/‐/g, "-");
eelam = eelam.replace(/>/g, "?");
eelam = eelam.replace(/:/g, "்");
eelam = eelam.replace(/\^/g, "ூ");
eelam = eelam.replace(/\^/g, "ூ");
eelam = eelam.replace(/@/g, "்");

eelam = eelam.replace(/0000/g, ",");


document.tamuni.box2.value=eelam; 
} 
// End --> 

