﻿<!-- Begin

var eelam;
function startText4() {
eelam = document.tamuni.box1.value;

eelam = eelam.replace(/Xau/g, "க்ஷௌ");
eelam = eelam.replace(/Xai/g, "க்ஷை");
eelam = eelam.replace(/Xaa/g, "க்ஷா");
eelam = eelam.replace(/XA/g, "க்ஷா");
eelam = eelam.replace(/Xa/g, "க்ஷ");
eelam = eelam.replace(/Xii/g, "க்ஷீ");
eelam = eelam.replace(/Xi/g, "க்ஷி");
eelam = eelam.replace(/XI/g, "க்ஷீ");

eelam = eelam.replace(/Xuu/g, "க்ஷூ");
eelam = eelam.replace(/Xu/g, "க்ஷு");
eelam = eelam.replace(/XU/g, "க்ஷூ");
eelam = eelam.replace(/Xee/g, "க்ஷே");
eelam = eelam.replace(/Xe/g, "க்ஷெ");
eelam = eelam.replace(/XE/g, "க்ஷே");
eelam = eelam.replace(/Xoo/g, "க்ஷோ");
eelam = eelam.replace(/Xo/g, "க்ஷொ");
eelam = eelam.replace(/XO/g, "க்ஷோ");


eelam = eelam.replace(/X/g, "க்ஷ்");

eelam = eelam.replace(/njau/g, "ஞௌ");
eelam = eelam.replace(/njai/g, "ஞை");
eelam = eelam.replace(/njee/g, "ஞே");
eelam = eelam.replace(/njoo/g, "ஞோ");
eelam = eelam.replace(/njaa/g, "ஞா");
eelam = eelam.replace(/njuu/g, "ஞூ");
eelam = eelam.replace(/njii/g, "ஞீ");
eelam = eelam.replace(/nja/g, "ஞ");
eelam = eelam.replace(/nji/g, "ஞி");
eelam = eelam.replace(/njI/g, "ஞீ");
eelam = eelam.replace(/njA/g, "ஞா");
eelam = eelam.replace(/nje/g, "ஞெ");
eelam = eelam.replace(/njE/g, "ஞே");
eelam = eelam.replace(/njo/g, "ஞொ");
eelam = eelam.replace(/njO/g, "ஞோ");
eelam = eelam.replace(/nju/g, "ஞு");
eelam = eelam.replace(/njU/g, "ஞூ");

eelam = eelam.replace(/nj/g, "ஞ்");


eelam = eelam.replace(/ngau/g, "ஙௌ");
eelam = eelam.replace(/ngai/g, "ஙை");
eelam = eelam.replace(/ngee/g, "ஙே");
eelam = eelam.replace(/ngoo/g, "ஙோ");
eelam = eelam.replace(/ngaa/g, "ஙா");
eelam = eelam.replace(/nguu/g, "ஙூ");
eelam = eelam.replace(/ngii/g, "ஙீ");
eelam = eelam.replace(/nga/g, "ங");
eelam = eelam.replace(/ngi/g, "ஙி");
eelam = eelam.replace(/ngI/g, "ஙீ");
eelam = eelam.replace(/ngA/g, "ஙா");
eelam = eelam.replace(/nge/g, "ஙெ");
eelam = eelam.replace(/ngE/g, "ஙே");
eelam = eelam.replace(/ngo/g, "ஙொ");
eelam = eelam.replace(/ngO/g, "ஙோ");
eelam = eelam.replace(/ngu/g, "ஙு");
eelam = eelam.replace(/ngU/g, "ஙூ");

eelam = eelam.replace(/ng/g, "ங்");



eelam = eelam.replace(/shau/g, "ஷௌ");
eelam = eelam.replace(/shai/g, "ஷை");
eelam = eelam.replace(/shee/g, "ஷே");
eelam = eelam.replace(/shoo/g, "ஷோ");
eelam = eelam.replace(/shaa/g, "ஷா");
eelam = eelam.replace(/shuu/g, "ஷூ");
eelam = eelam.replace(/shii/g, "ஷீ");
eelam = eelam.replace(/sha/g, "ஷ");
eelam = eelam.replace(/shi/g, "ஷி");
eelam = eelam.replace(/shI/g, "ஷீ");
eelam = eelam.replace(/shA/g, "ஷா");
eelam = eelam.replace(/she/g, "ஷெ");
eelam = eelam.replace(/shE/g, "ஷே");
eelam = eelam.replace(/sho/g, "ஷொ");
eelam = eelam.replace(/shO/g, "ஷோ");
eelam = eelam.replace(/shu/g, "ஷு");
eelam = eelam.replace(/shU/g, "ஷூ");

eelam = eelam.replace(/sh/g, "ஷ்");

eelam = eelam.replace(/ nau/g, " நௌ");
eelam = eelam.replace(/ nai/g, " நை");
eelam = eelam.replace(/ nee/g, " நே");
eelam = eelam.replace(/ noo/g, " நோ");
eelam = eelam.replace(/ naa/g, " நா");
eelam = eelam.replace(/ nuu/g, " நூ");
eelam = eelam.replace(/ nii/g, " நீ");
eelam = eelam.replace(/ na/g, " ந");
eelam = eelam.replace(/ ni/g, " நி");
eelam = eelam.replace(/ nI/g, " நீ");
eelam = eelam.replace(/ nA/g, " நா");
eelam = eelam.replace(/ ne/g, " நெ");
eelam = eelam.replace(/ nE/g, " நே");
eelam = eelam.replace(/ no/g, " நொ");
eelam = eelam.replace(/ nO/g, " நோ");
eelam = eelam.replace(/ nu/g, " நு");
eelam = eelam.replace(/ nU/g, " நூ");

eelam = eelam.replace(/ nth/g, " ந்");

eelam = eelam.replace(/-nau/g, "நௌ");
eelam = eelam.replace(/-nai/g, "நை");
eelam = eelam.replace(/-nee/g, "நே");
eelam = eelam.replace(/-noo/g, "நோ");
eelam = eelam.replace(/-naa/g, "நா");
eelam = eelam.replace(/-nuu/g, "நூ");
eelam = eelam.replace(/-nii/g, "நீ");
eelam = eelam.replace(/-na/g, "ந");
eelam = eelam.replace(/-ni/g, "நி");
eelam = eelam.replace(/-nI/g, "நீ");
eelam = eelam.replace(/-nA/g, "நா");
eelam = eelam.replace(/-ne/g, "நெ");
eelam = eelam.replace(/-nE/g, "நே");
eelam = eelam.replace(/-no/g, "நொ");
eelam = eelam.replace(/-nO/g, "நோ");
eelam = eelam.replace(/-nu/g, "நு");
eelam = eelam.replace(/-nU/g, "நூ");

eelam = eelam.replace(/n-au/g, "நௌ");
eelam = eelam.replace(/n-ai/g, "நை");
eelam = eelam.replace(/n-ee/g, "நே");
eelam = eelam.replace(/n-oo/g, "நோ");
eelam = eelam.replace(/n-aa/g, "நா");
eelam = eelam.replace(/n-uu/g, "நூ");
eelam = eelam.replace(/n-ii/g, "நீ");
eelam = eelam.replace(/n-a/g, "ந");
eelam = eelam.replace(/n-i/g, "நி");
eelam = eelam.replace(/n-I/g, "நீ");
eelam = eelam.replace(/n-A/g, "நா");
eelam = eelam.replace(/n-e/g, "நெ");
eelam = eelam.replace(/n-E/g, "நே");
eelam = eelam.replace(/n-o/g, "நொ");
eelam = eelam.replace(/n-O/g, "நோ");
eelam = eelam.replace(/n-u/g, "நு");
eelam = eelam.replace(/n-U/g, "நூ");

eelam = eelam.replace(/wau/g, "நௌ");
eelam = eelam.replace(/wai/g, "நை");
eelam = eelam.replace(/wee/g, "நே");
eelam = eelam.replace(/woo/g, "நோ");
eelam = eelam.replace(/waa/g, "நா");
eelam = eelam.replace(/wuu/g, "நூ");
eelam = eelam.replace(/wii/g, "நீ");
eelam = eelam.replace(/wa/g, "ந");
eelam = eelam.replace(/wi/g, "நி");
eelam = eelam.replace(/wI/g, "நீ");
eelam = eelam.replace(/wA/g, "நா");
eelam = eelam.replace(/we/g, "நெ");
eelam = eelam.replace(/wE/g, "நே");
eelam = eelam.replace(/wo/g, "நொ");
eelam = eelam.replace(/wO/g, "நோ");
eelam = eelam.replace(/wu/g, "நு");
eelam = eelam.replace(/wU/g, "நூ");



eelam = eelam.replace(/ n/g, " ந்");
eelam = eelam.replace(/n-/g, "ந்");
eelam = eelam.replace(/-n/g, "ந்");
eelam = eelam.replace(/w/g, "ந்");




eelam = eelam.replace(/nthau/g, "ந்தௌ");
eelam = eelam.replace(/nthai/g, "ந்தை");
eelam = eelam.replace(/nthee/g, "ந்தே");
eelam = eelam.replace(/nthoo/g, "ந்தோ");
eelam = eelam.replace(/nthaa/g, "ந்தா");
eelam = eelam.replace(/nthuu/g, "ந்தூ");
eelam = eelam.replace(/nthii/g, "ந்தீ");
eelam = eelam.replace(/ntha/g, "ந்த");
eelam = eelam.replace(/nthi/g, "ந்தி");
eelam = eelam.replace(/nthI/g, "ந்தீ");
eelam = eelam.replace(/nthA/g, "ந்தா");
eelam = eelam.replace(/nthe/g, "ந்தெ");
eelam = eelam.replace(/nthE/g, "ந்தே");
eelam = eelam.replace(/ntho/g, "ந்தொ");
eelam = eelam.replace(/nthO/g, "ந்தோ");
eelam = eelam.replace(/nthu/g, "ந்து");
eelam = eelam.replace(/nthU/g, "ந்தூ");
eelam = eelam.replace(/nth/g, "ந்");




eelam = eelam.replace(/dhau/g, "தௌ");
eelam = eelam.replace(/dhai/g, "தை");
eelam = eelam.replace(/dhee/g, "தே");
eelam = eelam.replace(/dhoo/g, "தோ");
eelam = eelam.replace(/dhaa/g, "தா");
eelam = eelam.replace(/dhuu/g, "தூ");
eelam = eelam.replace(/dhii/g, "தீ");
eelam = eelam.replace(/dha/g, "த");
eelam = eelam.replace(/dhi/g, "தி");
eelam = eelam.replace(/dhI/g, "தீ");
eelam = eelam.replace(/dhA/g, "தா");
eelam = eelam.replace(/dhe/g, "தெ");
eelam = eelam.replace(/dhE/g, "தே");
eelam = eelam.replace(/dho/g, "தொ");
eelam = eelam.replace(/dhO/g, "தோ");
eelam = eelam.replace(/dhu/g, "து");
eelam = eelam.replace(/dhU/g, "தூ");

eelam = eelam.replace(/dh/g, "த்");

eelam = eelam.replace(/chau/g, "சௌ");
eelam = eelam.replace(/chai/g, "சை");
eelam = eelam.replace(/chee/g, "சே");
eelam = eelam.replace(/choo/g, "சோ");
eelam = eelam.replace(/chaa/g, "சா");
eelam = eelam.replace(/chuu/g, "சூ");
eelam = eelam.replace(/chii/g, "சீ");
eelam = eelam.replace(/cha/g, "ச");
eelam = eelam.replace(/chi/g, "சி");
eelam = eelam.replace(/chI/g, "சீ");
eelam = eelam.replace(/chA/g, "சா");
eelam = eelam.replace(/che/g, "செ");
eelam = eelam.replace(/chE/g, "சே");
eelam = eelam.replace(/cho/g, "சொ");
eelam = eelam.replace(/chO/g, "சோ");
eelam = eelam.replace(/chu/g, "சு");
eelam = eelam.replace(/chU/g, "சூ");

eelam = eelam.replace(/ch/g, "ச்");

eelam = eelam.replace(/zhau/g, "ழௌ");
eelam = eelam.replace(/zhai/g, "ழை");
eelam = eelam.replace(/zhee/g, "ழே");
eelam = eelam.replace(/zhoo/g, "ழோ");
eelam = eelam.replace(/zhaa/g, "ழா");
eelam = eelam.replace(/zhuu/g, "ழூ");
eelam = eelam.replace(/zhii/g, "ழீ");
eelam = eelam.replace(/zha/g, "ழ");
eelam = eelam.replace(/zhi/g, "ழி");
eelam = eelam.replace(/zhI/g, "ழீ");
eelam = eelam.replace(/zhA/g, "ழா");
eelam = eelam.replace(/zhe/g, "ழெ");
eelam = eelam.replace(/zhE/g, "ழே");
eelam = eelam.replace(/zho/g, "ழொ");
eelam = eelam.replace(/zhO/g, "ழோ");
eelam = eelam.replace(/zhu/g, "ழு");
eelam = eelam.replace(/zhU/g, "ழூ");

eelam = eelam.replace(/zh/g, "ழ்");
eelam = eelam.replace(/zau/g, "ழௌ");
eelam = eelam.replace(/zai/g, "ழை");
eelam = eelam.replace(/zee/g, "ழே");
eelam = eelam.replace(/zoo/g, "ழோ");
eelam = eelam.replace(/zaa/g, "ழா");
eelam = eelam.replace(/zuu/g, "ழூ");
eelam = eelam.replace(/zii/g, "ழீ");
eelam = eelam.replace(/za/g, "ழ");
eelam = eelam.replace(/zi/g, "ழி");
eelam = eelam.replace(/zI/g, "ழீ");
eelam = eelam.replace(/zA/g, "ழா");
eelam = eelam.replace(/ze/g, "ழெ");
eelam = eelam.replace(/zE/g, "ழே");
eelam = eelam.replace(/zo/g, "ழொ");
eelam = eelam.replace(/zO/g, "ழோ");
eelam = eelam.replace(/zu/g, "ழு");
eelam = eelam.replace(/zU/g, "ழூ");

eelam = eelam.replace(/z/g, "ழ்");

eelam = eelam.replace(/jau/g, "ஜௌ");
eelam = eelam.replace(/jai/g, "ஜை");
eelam = eelam.replace(/jee/g, "ஜே");
eelam = eelam.replace(/joo/g, "ஜோ");
eelam = eelam.replace(/jaa/g, "ஜா");
eelam = eelam.replace(/juu/g, "ஜூ");
eelam = eelam.replace(/jii/g, "ஜீ");
eelam = eelam.replace(/ja/g, "ஜ");
eelam = eelam.replace(/ji/g, "ஜி");
eelam = eelam.replace(/jI/g, "ஜீ");
eelam = eelam.replace(/jA/g, "ஜா");
eelam = eelam.replace(/je/g, "ஜெ");
eelam = eelam.replace(/jE/g, "ஜே");
eelam = eelam.replace(/jo/g, "ஜொ");
eelam = eelam.replace(/jO/g, "ஜோ");
eelam = eelam.replace(/ju/g, "ஜு");
eelam = eelam.replace(/jU/g, "ஜூ");

eelam = eelam.replace(/j/g, "ஜ்");


eelam = eelam.replace(/thau/g, "தௌ");
eelam = eelam.replace(/thai/g, "தை");
eelam = eelam.replace(/thee/g, "தே");
eelam = eelam.replace(/thoo/g, "தோ");
eelam = eelam.replace(/thaa/g, "தா");
eelam = eelam.replace(/thuu/g, "தூ");
eelam = eelam.replace(/thii/g, "தீ");
eelam = eelam.replace(/tha/g, "த");
eelam = eelam.replace(/thi/g, "தி");
eelam = eelam.replace(/thI/g, "தீ");
eelam = eelam.replace(/thA/g, "தா");
eelam = eelam.replace(/the/g, "தெ");
eelam = eelam.replace(/thE/g, "தே");
eelam = eelam.replace(/tho/g, "தொ");
eelam = eelam.replace(/thO/g, "தோ");
eelam = eelam.replace(/thu/g, "து");
eelam = eelam.replace(/thU/g, "தூ");

eelam = eelam.replace(/th/g, "த்");

eelam = eelam.replace(/-hau/g, "ஹௌ");
eelam = eelam.replace(/-hai/g, "ஹை");
eelam = eelam.replace(/-hee/g, "ஹே");
eelam = eelam.replace(/-hoo/g, "ஹோ");
eelam = eelam.replace(/-haa/g, "ஹா");
eelam = eelam.replace(/-huu/g, "ஹூ");
eelam = eelam.replace(/-hii/g, "ஹீ");
eelam = eelam.replace(/-ha/g, "ஹ");
eelam = eelam.replace(/-hi/g, "ஹி");
eelam = eelam.replace(/-hI/g, "ஹீ");
eelam = eelam.replace(/-hA/g, "ஹா");
eelam = eelam.replace(/-he/g, "ஹெ");
eelam = eelam.replace(/-hE/g, "ஹே");
eelam = eelam.replace(/-ho/g, "ஹொ");
eelam = eelam.replace(/-hO/g, "ஹோ");
eelam = eelam.replace(/-hu/g, "ஹு");
eelam = eelam.replace(/-hU/g, "ஹூ");

eelam = eelam.replace(/-h/g, "ஹ்");

eelam = eelam.replace(/hau/g, "கௌ");
eelam = eelam.replace(/hai/g, "கை");
eelam = eelam.replace(/hee/g, "கே");
eelam = eelam.replace(/hoo/g, "கோ");
eelam = eelam.replace(/haa/g, "கா");
eelam = eelam.replace(/huu/g, "கூ");
eelam = eelam.replace(/hii/g, "கீ");
eelam = eelam.replace(/ha/g, "க");
eelam = eelam.replace(/hi/g, "கி");
eelam = eelam.replace(/hI/g, "கீ");
eelam = eelam.replace(/hA/g, "கா");
eelam = eelam.replace(/he/g, "கெ");
eelam = eelam.replace(/hE/g, "கே");
eelam = eelam.replace(/ho/g, "கொ");
eelam = eelam.replace(/hO/g, "கோ");
eelam = eelam.replace(/hu/g, "கு");
eelam = eelam.replace(/hU/g, "கூ");

eelam = eelam.replace(/h/g, "க்");

eelam = eelam.replace(/kau/g, "கௌ");
eelam = eelam.replace(/kai/g, "கை");
eelam = eelam.replace(/kee/g, "கே");
eelam = eelam.replace(/koo/g, "கோ");
eelam = eelam.replace(/kaa/g, "கா");
eelam = eelam.replace(/kuu/g, "கூ");
eelam = eelam.replace(/kii/g, "கீ");
eelam = eelam.replace(/ka/g, "க");
eelam = eelam.replace(/ki/g, "கி");
eelam = eelam.replace(/kI/g, "கீ");
eelam = eelam.replace(/kA/g, "கா");
eelam = eelam.replace(/ke/g, "கெ");
eelam = eelam.replace(/kE/g, "கே");
eelam = eelam.replace(/ko/g, "கொ");
eelam = eelam.replace(/kO/g, "கோ");
eelam = eelam.replace(/ku/g, "கு");
eelam = eelam.replace(/kU/g, "கூ");

eelam = eelam.replace(/k/g, "க்");


eelam = eelam.replace(/-sau/g, "ஸௌ");
eelam = eelam.replace(/-sai/g, "ஸை");
eelam = eelam.replace(/-see/g, "ஸே");
eelam = eelam.replace(/-soo/g, "ஸோ");
eelam = eelam.replace(/-saa/g, "ஸா");
eelam = eelam.replace(/-suu/g, "ஸூ");
eelam = eelam.replace(/-sii/g, "ஸீ");
eelam = eelam.replace(/-sa/g, "ஸ");
eelam = eelam.replace(/-si/g, "ஸி");
eelam = eelam.replace(/-sI/g, "ஸீ");
eelam = eelam.replace(/-sA/g, "ஸா");
eelam = eelam.replace(/-se/g, "ஸெ");
eelam = eelam.replace(/-sE/g, "ஸே");
eelam = eelam.replace(/-so/g, "ஸொ");
eelam = eelam.replace(/-sO/g, "ஸோ");
eelam = eelam.replace(/-su/g, "ஸு");
eelam = eelam.replace(/-sU/g, "ஸூ");

eelam = eelam.replace(/-s/g, "ஸ்");

eelam = eelam.replace(/Sau/g, "ஸௌ");
eelam = eelam.replace(/Sai/g, "ஸை");
eelam = eelam.replace(/See/g, "ஸே");
eelam = eelam.replace(/Soo/g, "ஸோ");
eelam = eelam.replace(/Saa/g, "ஸா");
eelam = eelam.replace(/Suu/g, "ஸூ");
eelam = eelam.replace(/Sii/g, "ஸீ");
eelam = eelam.replace(/Sa/g, "ஸ");
eelam = eelam.replace(/Si/g, "ஸி");
eelam = eelam.replace(/SI/g, "ஸீ");
eelam = eelam.replace(/SA/g, "ஸா");
eelam = eelam.replace(/Se/g, "ஸெ");
eelam = eelam.replace(/SE/g, "ஸே");
eelam = eelam.replace(/So/g, "ஸொ");
eelam = eelam.replace(/SO/g, "ஸோ");
eelam = eelam.replace(/Su/g, "ஸு");
eelam = eelam.replace(/SU/g, "ஸூ");

eelam = eelam.replace(/S/g, "ஸ்");


eelam = eelam.replace(/rau/g, "ரௌ");
eelam = eelam.replace(/rai/g, "ரை");
eelam = eelam.replace(/ree/g, "ரே");
eelam = eelam.replace(/roo/g, "ரோ");
eelam = eelam.replace(/raa/g, "ரா");
eelam = eelam.replace(/ruu/g, "ரூ");
eelam = eelam.replace(/rii/g, "ரீ");
eelam = eelam.replace(/ra/g, "ர");
eelam = eelam.replace(/ri/g, "ரி");
eelam = eelam.replace(/rI/g, "ரீ");
eelam = eelam.replace(/rA/g, "ரா");
eelam = eelam.replace(/re/g, "ரெ");
eelam = eelam.replace(/rE/g, "ரே");
eelam = eelam.replace(/ro/g, "ரொ");
eelam = eelam.replace(/rO/g, "ரோ");
eelam = eelam.replace(/ru/g, "ரு");
eelam = eelam.replace(/rU/g, "ரூ");

eelam = eelam.replace(/r/g, "ர்");

eelam = eelam.replace(/Rau/g, "றௌ");
eelam = eelam.replace(/Rai/g, "றை");
eelam = eelam.replace(/Ree/g, "றே");
eelam = eelam.replace(/Roo/g, "றோ");
eelam = eelam.replace(/Raa/g, "றா");
eelam = eelam.replace(/Ruu/g, "றூ");
eelam = eelam.replace(/Rii/g, "றீ");
eelam = eelam.replace(/Ra/g, "ற");
eelam = eelam.replace(/Ri/g, "றி");
eelam = eelam.replace(/RI/g, "றீ");
eelam = eelam.replace(/RA/g, "றா");
eelam = eelam.replace(/Re/g, "றெ");
eelam = eelam.replace(/RE/g, "றே");
eelam = eelam.replace(/Ro/g, "றொ");
eelam = eelam.replace(/RO/g, "றோ");
eelam = eelam.replace(/Ru/g, "று");
eelam = eelam.replace(/RU/g, "றூ");

eelam = eelam.replace(/R/g, "ற்");

eelam = eelam.replace(/tau/g, "டௌ");
eelam = eelam.replace(/tai/g, "டை");
eelam = eelam.replace(/tee/g, "டே");
eelam = eelam.replace(/too/g, "டோ");
eelam = eelam.replace(/taa/g, "டா");
eelam = eelam.replace(/tuu/g, "டூ");
eelam = eelam.replace(/tii/g, "டீ");
eelam = eelam.replace(/ta/g, "ட");
eelam = eelam.replace(/ti/g, "டி");
eelam = eelam.replace(/tI/g, "டீ");
eelam = eelam.replace(/tA/g, "டா");
eelam = eelam.replace(/te/g, "டெ");
eelam = eelam.replace(/tE/g, "டே");
eelam = eelam.replace(/to/g, "டொ");
eelam = eelam.replace(/tO/g, "டோ");
eelam = eelam.replace(/tu/g, "டு");
eelam = eelam.replace(/tU/g, "டூ");

eelam = eelam.replace(/t/g, "ட்");



eelam = eelam.replace(/sau/g, "சௌ");
eelam = eelam.replace(/sai/g, "சை");
eelam = eelam.replace(/see/g, "சே");
eelam = eelam.replace(/soo/g, "சோ");
eelam = eelam.replace(/saa/g, "சா");
eelam = eelam.replace(/suu/g, "சூ");
eelam = eelam.replace(/sii/g, "சீ");
eelam = eelam.replace(/sa/g, "ச");
eelam = eelam.replace(/si/g, "சி");
eelam = eelam.replace(/sI/g, "சீ");
eelam = eelam.replace(/sA/g, "சா");
eelam = eelam.replace(/se/g, "செ");
eelam = eelam.replace(/sE/g, "சே");
eelam = eelam.replace(/so/g, "சொ");
eelam = eelam.replace(/sO/g, "சோ");
eelam = eelam.replace(/su/g, "சு");
eelam = eelam.replace(/sU/g, "சூ");

eelam = eelam.replace(/s/g, "ச்");
eelam = eelam.replace(/pau/g, "பௌ");
eelam = eelam.replace(/pai/g, "பை");
eelam = eelam.replace(/pee/g, "பே");
eelam = eelam.replace(/poo/g, "போ");
eelam = eelam.replace(/paa/g, "பா");
eelam = eelam.replace(/puu/g, "பூ");
eelam = eelam.replace(/pii/g, "பீ");
eelam = eelam.replace(/pa/g, "ப");
eelam = eelam.replace(/pi/g, "பி");
eelam = eelam.replace(/pI/g, "பீ");
eelam = eelam.replace(/pA/g, "பா");
eelam = eelam.replace(/pe/g, "பெ");
eelam = eelam.replace(/pE/g, "பே");
eelam = eelam.replace(/po/g, "பொ");
eelam = eelam.replace(/pO/g, "போ");
eelam = eelam.replace(/pu/g, "பு");
eelam = eelam.replace(/pU/g, "பூ");

eelam = eelam.replace(/p/g, "ப்");

eelam = eelam.replace(/bau/g, "பௌ");
eelam = eelam.replace(/bai/g, "பை");
eelam = eelam.replace(/bee/g, "பே");
eelam = eelam.replace(/boo/g, "போ");
eelam = eelam.replace(/baa/g, "பா");
eelam = eelam.replace(/buu/g, "பூ");
eelam = eelam.replace(/bii/g, "பீ");
eelam = eelam.replace(/ba/g, "ப");
eelam = eelam.replace(/bi/g, "பி");
eelam = eelam.replace(/bI/g, "பீ");
eelam = eelam.replace(/bA/g, "பா");
eelam = eelam.replace(/be/g, "பெ");
eelam = eelam.replace(/bE/g, "பே");
eelam = eelam.replace(/bo/g, "பொ");
eelam = eelam.replace(/bO/g, "போ");
eelam = eelam.replace(/bu/g, "பு");
eelam = eelam.replace(/bU/g, "பூ");

eelam = eelam.replace(/b/g, "ப்");
eelam = eelam.replace(/mau/g, "மௌ");
eelam = eelam.replace(/mai/g, "மை");
eelam = eelam.replace(/mee/g, "மே");
eelam = eelam.replace(/moo/g, "மோ");
eelam = eelam.replace(/maa/g, "மா");
eelam = eelam.replace(/muu/g, "மூ");
eelam = eelam.replace(/mii/g, "மீ");
eelam = eelam.replace(/ma/g, "ம");
eelam = eelam.replace(/mi/g, "மி");
eelam = eelam.replace(/mI/g, "மீ");
eelam = eelam.replace(/mA/g, "மா");
eelam = eelam.replace(/me/g, "மெ");
eelam = eelam.replace(/mE/g, "மே");
eelam = eelam.replace(/mo/g, "மொ");
eelam = eelam.replace(/mO/g, "மோ");
eelam = eelam.replace(/mu/g, "மு");
eelam = eelam.replace(/mU/g, "மூ");

eelam = eelam.replace(/m/g, "ம்");

eelam = eelam.replace(/yau/g, "யௌ");
eelam = eelam.replace(/yai/g, "யை");
eelam = eelam.replace(/yee/g, "யே");
eelam = eelam.replace(/yoo/g, "யோ");
eelam = eelam.replace(/yaa/g, "யா");
eelam = eelam.replace(/yuu/g, "யூ");
eelam = eelam.replace(/yii/g, "யீ");
eelam = eelam.replace(/ya/g, "ய");
eelam = eelam.replace(/yi/g, "யி");
eelam = eelam.replace(/yI/g, "யீ");
eelam = eelam.replace(/yA/g, "யா");
eelam = eelam.replace(/ye/g, "யெ");
eelam = eelam.replace(/yE/g, "யே");
eelam = eelam.replace(/yo/g, "யொ");
eelam = eelam.replace(/yO/g, "யோ");
eelam = eelam.replace(/yu/g, "யு");
eelam = eelam.replace(/yU/g, "யூ");

eelam = eelam.replace(/y/g, "ய்");


eelam = eelam.replace(/dau/g, "டௌ");
eelam = eelam.replace(/dai/g, "டை");
eelam = eelam.replace(/dee/g, "டே");
eelam = eelam.replace(/doo/g, "டோ");
eelam = eelam.replace(/daa/g, "டா");
eelam = eelam.replace(/duu/g, "டூ");
eelam = eelam.replace(/dii/g, "டீ");
eelam = eelam.replace(/da/g, "ட");
eelam = eelam.replace(/di/g, "டி");
eelam = eelam.replace(/dI/g, "டீ");
eelam = eelam.replace(/dA/g, "டா");
eelam = eelam.replace(/de/g, "டெ");
eelam = eelam.replace(/dE/g, "டே");
eelam = eelam.replace(/do/g, "டொ");
eelam = eelam.replace(/dO/g, "டோ");
eelam = eelam.replace(/du/g, "டு");
eelam = eelam.replace(/dU/g, "டூ");

eelam = eelam.replace(/d/g, "ட்");


eelam = eelam.replace(/nau/g, "னௌ");
eelam = eelam.replace(/nai/g, "னை");
eelam = eelam.replace(/nee/g, "னே");
eelam = eelam.replace(/noo/g, "னோ");
eelam = eelam.replace(/naa/g, "னா");
eelam = eelam.replace(/nuu/g, "னூ");
eelam = eelam.replace(/nii/g, "னீ");
eelam = eelam.replace(/na/g, "ன");
eelam = eelam.replace(/ni/g, "னி");
eelam = eelam.replace(/nI/g, "னீ");
eelam = eelam.replace(/nA/g, "னா");
eelam = eelam.replace(/ne/g, "னெ");
eelam = eelam.replace(/nE/g, "னே");
eelam = eelam.replace(/no/g, "னொ");
eelam = eelam.replace(/nO/g, "னோ");
eelam = eelam.replace(/nu/g, "னு");
eelam = eelam.replace(/nU/g, "னூ");

eelam = eelam.replace(/n/g, "ன்");

eelam = eelam.replace(/Nau/g, "ணௌ");
eelam = eelam.replace(/Nai/g, "ணை");
eelam = eelam.replace(/Nee/g, "ணே");
eelam = eelam.replace(/Noo/g, "ணோ");
eelam = eelam.replace(/Naa/g, "ணா");
eelam = eelam.replace(/Nuu/g, "ணூ");
eelam = eelam.replace(/Nii/g, "ணீ");
eelam = eelam.replace(/Na/g, "ண");
eelam = eelam.replace(/Ni/g, "ணி");
eelam = eelam.replace(/NI/g, "ணீ");
eelam = eelam.replace(/NA/g, "ணா");
eelam = eelam.replace(/Ne/g, "ணெ");
eelam = eelam.replace(/NE/g, "ணே");
eelam = eelam.replace(/No/g, "ணொ");
eelam = eelam.replace(/NO/g, "ணோ");
eelam = eelam.replace(/Nu/g, "ணு");
eelam = eelam.replace(/NU/g, "ணூ");

eelam = eelam.replace(/N/g, "ண்");
eelam = eelam.replace(/lau/g, "லௌ");
eelam = eelam.replace(/lai/g, "லை");
eelam = eelam.replace(/lee/g, "லே");
eelam = eelam.replace(/loo/g, "லோ");
eelam = eelam.replace(/laa/g, "லா");
eelam = eelam.replace(/luu/g, "லூ");
eelam = eelam.replace(/lii/g, "லீ");
eelam = eelam.replace(/la/g, "ல");
eelam = eelam.replace(/li/g, "லி");
eelam = eelam.replace(/lI/g, "லீ");
eelam = eelam.replace(/lA/g, "லா");
eelam = eelam.replace(/le/g, "லெ");
eelam = eelam.replace(/lE/g, "லே");
eelam = eelam.replace(/lo/g, "லொ");
eelam = eelam.replace(/lO/g, "லோ");
eelam = eelam.replace(/lu/g, "லு");
eelam = eelam.replace(/lU/g, "லூ");

eelam = eelam.replace(/l/g, "ல்");
eelam = eelam.replace(/Lau/g, "ளௌ");
eelam = eelam.replace(/Lai/g, "ளை");
eelam = eelam.replace(/Lee/g, "ளே");
eelam = eelam.replace(/Loo/g, "ளோ");
eelam = eelam.replace(/Laa/g, "ளா");
eelam = eelam.replace(/Luu/g, "ளூ");
eelam = eelam.replace(/Lii/g, "ளீ");
eelam = eelam.replace(/La/g, "ள");
eelam = eelam.replace(/Li/g, "ளி");
eelam = eelam.replace(/LI/g, "ளீ");
eelam = eelam.replace(/LA/g, "ளா");
eelam = eelam.replace(/Le/g, "ளெ");
eelam = eelam.replace(/LE/g, "ளே");
eelam = eelam.replace(/Lo/g, "ளொ");
eelam = eelam.replace(/LO/g, "ளோ");
eelam = eelam.replace(/Lu/g, "ளு");
eelam = eelam.replace(/LU/g, "ளூ");

eelam = eelam.replace(/L/g, "ள்");



eelam = eelam.replace(/vau/g, "வௌ");
eelam = eelam.replace(/vai/g, "வை");
eelam = eelam.replace(/vee/g, "வே");
eelam = eelam.replace(/voo/g, "வோ");
eelam = eelam.replace(/vaa/g, "வா");
eelam = eelam.replace(/vuu/g, "வூ");
eelam = eelam.replace(/vii/g, "வீ");
eelam = eelam.replace(/va/g, "வ");
eelam = eelam.replace(/vi/g, "வி");
eelam = eelam.replace(/vI/g, "வீ");
eelam = eelam.replace(/vA/g, "வா");
eelam = eelam.replace(/ve/g, "வெ");
eelam = eelam.replace(/vE/g, "வே");
eelam = eelam.replace(/vo/g, "வொ");
eelam = eelam.replace(/vO/g, "வோ");
eelam = eelam.replace(/vu/g, "வு");
eelam = eelam.replace(/vU/g, "வூ");

eelam = eelam.replace(/v/g, "வ்");





eelam = eelam.replace(/gau/g, "கௌ");
eelam = eelam.replace(/gai/g, "கை");
eelam = eelam.replace(/gee/g, "கே");
eelam = eelam.replace(/goo/g, "கோ");
eelam = eelam.replace(/gaa/g, "கா");
eelam = eelam.replace(/guu/g, "கூ");
eelam = eelam.replace(/gii/g, "கீ");
eelam = eelam.replace(/ga/g, "க");
eelam = eelam.replace(/gi/g, "கி");
eelam = eelam.replace(/gI/g, "கீ");
eelam = eelam.replace(/gA/g, "கா");
eelam = eelam.replace(/ge/g, "கெ");
eelam = eelam.replace(/gE/g, "கே");
eelam = eelam.replace(/go/g, "கொ");
eelam = eelam.replace(/gO/g, "கோ");
eelam = eelam.replace(/gu/g, "கு");
eelam = eelam.replace(/gU/g, "கூ");

eelam = eelam.replace(/g/g, "க்");














eelam = eelam.replace(/au/g, "ஔ");
eelam = eelam.replace(/ai/g, "ஐ");
eelam = eelam.replace(/aa/g, "ஆ");
eelam = eelam.replace(/ee/g, "ஏ");
eelam = eelam.replace(/ii/g, "ஈ");
eelam = eelam.replace(/uu/g, "ஊ");
eelam = eelam.replace(/oo/g, "ஓ");




eelam = eelam.replace(/-1000/g, "௲");

eelam = eelam.replace(/-100/g, "௱");

eelam = eelam.replace(/-10/g, "௰");
eelam = eelam.replace(/-1/g, "௧");

eelam = eelam.replace(/-2/g, "௨");
eelam = eelam.replace(/-3/g, "௩");

eelam = eelam.replace(/-4/g, "௪");
eelam = eelam.replace(/-5/g, "௫");

eelam = eelam.replace(/-6/g, "௬");
eelam = eelam.replace(/-7/g, "௭");

eelam = eelam.replace(/-8/g, "௮");
eelam = eelam.replace(/-9/g, "௯");




eelam = eelam.replace(/i/g, "இ");
eelam = eelam.replace(/I/g, "ஈ");



eelam = eelam.replace(/a/g, "அ");

eelam = eelam.replace(/A/g, "ஆ");

eelam = eelam.replace(/e/g, "எ");
eelam = eelam.replace(/E/g, "ஏ");
eelam = eelam.replace(/i/g, "இ");
eelam = eelam.replace(/I/g, "ஈ");
eelam = eelam.replace(/u/g, "உ");
eelam = eelam.replace(/U/g, "ஊ");
eelam = eelam.replace(/o/g, "ஒ");
eelam = eelam.replace(/O/g, "ஓ");

eelam = eelam.replace(/q/g, "ஃ");












document.tamuni.box2.value=eelam;
}
//  End -->